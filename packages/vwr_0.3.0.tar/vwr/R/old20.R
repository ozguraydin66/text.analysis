old20 <-
function(sources, targets, method='levenshtein', parallel=FALSE){
    return(ald(sources, targets, 20, method=method, parallel=parallel))
}

